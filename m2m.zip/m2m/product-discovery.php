<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
<header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li>
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Product Discovery</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Validating Business Ideas with <span>Product Discovery</span></h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>
                                Before taking the big step in a business, you need to identify if your product addresses real people problems and is able to solve them. That’s why product discovery is an essential step before taking your product to market. To avoid disconnect between user needs and product, you need professional help to conduct product discovery.
                                <br><br>
                                M2M helps businesses identify gaps in their product vision through an in-depth analysis of their vision, objective, users and the market so that they can avert risks right from the start. Our startup and enterprise product discovery service enables you to not only lay the groundwork for the remainder of the project but also reveal the real pain points and discover value faster and cheaper.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>Explore the business before moving to the product development offer</li>
                            <li>Creating an SRS document describing the scope, features, architecture, & technology stack to set the product on the project roadmap</li>
                            <li>Create a clickable prototype illustrating how the final product will function with its aesthetics</li>
                            <li>Build a project timeline along with several milestones and dependencies with an estimate of the budget to develop your software product</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid pb-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2><span>Product Discovery</span> Phase Deliverables</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                                    <h4>Software Requirement Specification</h4>
                                    <p>An SRS document comprehensively describes the scope, features, architecture, and technology stack of a software product. Enterprise product discovery services yield such a document that helps set the stage for subsequent development.</p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                                    <h4>Project Roadmap</h4>
                                    <p>This is a snapshot of the project’s goals and objectives highlighted on a timeline to serve as a milestone for various development stages.</p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                                    <h4>Clickable Prototype</h4>
                                    <p>A collection of user interface screens to illustrate how the final product will function along with its core aesthetics.</p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                                    <h4>Product Backlog and Roadmap</h4>
                                    <p>This set of deliverables breaks down step-by-step the work structure needed to develop the software product. A product roadmap highlights the project timeline along with several milestones and dependencies.</p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                                    <h4>Estimates</h4>
                                    <p>You will also receive an estimate of the budget to develop your software product. The budget stated during product discovery is unlikely to shift significantly unless the project itself does.</p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Our <span class="text-white">Product Discovery</span> Process</h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2 app-dev-box web-dev-cell">
                    <h2 class="text-white font-weight-bold">Exploration</h2>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">1</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Initial Discovery</h4>
                                <p class="mb-0 text-left">You tell us and we listen about the primary aim of your product and the challenge it will solve for its users. Our team familiarizes itself with the why behind your product.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">2</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Onsite Visit</h4>
                                <p class="mb-0 text-left">We visit you and discuss the ins and outs of the project in-person. Under special circumstances, we meet virtually and kick off the discovery process.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">3</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Product Visioning</h4>
                                <p class="mb-0 text-left">We define your vision for your product and specify what success would look like for you. Every product development should follow a clear vision.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">4</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Technology Discovery</h4>
                                <p class="mb-0 text-left">What would your product take to build? In this stage, we identify the required underlying technology pieces, including software and third-party APIs.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">5</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Stakeholder Interviews</h4>
                                <p class="mb-0 text-left">We identify and speak with key stakeholders, including product owners, end-users, administrators, developers, investors, and align their vision for the product.</p>
                            </div>
                        </div>
                    </div>

                    <h2 class="text-white font-weight-bold mt-5">Ideation</h2>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">1</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Follow-Up Discussion</h4>
                                <p class="mb-0 text-left">We review the data and information we have so far and identify gaps, register agreements and disagreements, and chalk out the next steps.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">2</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Approach Definition</h4>
                                <p class="mb-0 text-left">How would you approach the development of your product? In this stage, we identify and build on a few possible approaches you could take.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">3</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Validation of Plan</h4>
                                <p class="mb-0 text-left">We brainstorm the plan of development for your product and validate it against real users and use cases. A/B testing also helps find out what users prefer.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">4</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Documentation of Findings</h4>
                                <p class="mb-0 text-left">Now, we put it all together in a neat document that you can refer back to throughout the development process to ensure you stay on track.</p>
                            </div>
                        </div>
                    </div>

                    <h2 class="text-white font-weight-bold mt-5">Presentation</h2>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">1</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Review Findings</h4>
                                <p class="mb-0 text-left">M2M team presents findings of the discovery phase for you to review the output of the product discovery service to spot gaps for improvement.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">2</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Revisions</h4>
                                <p class="mb-0 text-left">We optimize the discovery document to fit your vision, the user’s needs and the goals of the product. We invite your feedback and our experts’ opinions.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">3</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Final Presentation</h4>
                                <p class="mb-0 text-left">This wraps up the startup product discovery service with a final presentation of the building blocks for your product. We hand over the deliverables to you now.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative py-6">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center">Benefits of a <span>Product Discovery</span> Phase</h2>
                </div>
                <div class="col-12">
                    <div class="rnd-cell">
                        <div class="rnd-box">
                            <img src="assets/rnd (2).png">
                            <div class="rnd-box-con">
                                <h4>Scope of Project</h4>
                                <p>Eliminate guesswork and identify project scope to accurately estimate budget and timelines.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (3).png">
                            <div class="rnd-box-con">
                                <h4>Realistic Expectations</h4>
                                <p>Whether your idea is customer-facing or for your own good use, set the right expectations so you can meet them successfully.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (1).png">
                            <div class="rnd-box-con">
                                <h4>Risk Mapping</h4>
                                <p>Any risks in pursuing an idea can easily surface through a product discovery phase. Learn about budget and timeline overruns early on.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (2).png">
                            <div class="rnd-box-con">
                                <h4>User-Centric Development</h4>
                                <p>Analyze and make data-driven design decisions for an exceptional user experience.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (3).png">
                            <div class="rnd-box-con">
                                <h4>Prevent Costs</h4>
                                <p>Safeguard budget estimates by avoiding the need to make expensive changes to the product during ripe development stages.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (1).png">
                            <div class="rnd-box-con">
                                <h4>Gauge Competition</h4>
                                <p>As part of the startup product discovery service, you will also size up your competitors and counter them.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                        <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                        <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                        <li><a href="devops.php">DevOps as a Service</a></li>
                                        <li><a href="product-discovery.php">Product Discovery</a></li>
                                        <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
                if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".has-drop").removeClass('active-a');
                } else {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                    $(".has-drop").removeClass('active-a');
                    $(this).parent().find(".has-drop").addClass('active-a');
                }
            });
    });
</script>
</html>