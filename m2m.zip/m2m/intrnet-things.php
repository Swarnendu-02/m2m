<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
    <header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a>Services</a>
                                <ul class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li>
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Internet of Things</h3>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Unlock <span>Business</span> Insights</h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>
                                A connected ecosystem is the future of businesses. With KiwiTech’s IoT services, you can control, manage and leverage connected devices across a spectrum of use cases to fuel your digital transformation.
                                <br><br>
                                A preferred IoT development partner to some of the most disruptive startups and leading corporations, we understand that the Internet of Things is not just about connectivity – it’s about what this connectivity enables. We offer services that span the entire lifecycle of IoT-related initiatives, bring tangible value and drive resiliency. We help clients succeed by applying our business, design, and technology expertise to get their best ideas to market faster.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>Designing a coherent and seamless user experience across devices and software</li>
                            <li>Our IoT applications can aggregate sensor data from devices and process it in real-time or batches and enable H2M and M2M communication.</li>
                            <li>Accelerate time-to-ROI and actualize value in your IoT app.</li>
                            <li>Conducting maintenance and testing services of your IoT applications and services.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2>Our <span>IoT</span> Service Offerings</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Data Retrieval</h4>
                                    <p class="mb-0">Gather data from a variety of hardware sources. Our IoT applications allow structuring and secure storage of the data in the cloud for ready access.</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Big Data Analysis</h4>
                                    <p class="mb-0">Obtain business-critical insights by analyzing big data captured from a variety of sources to facilitate decision making.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Data Processing</h4>
                                    <p class="mb-0">Our IoT applications can aggregate sensor data from devices and process it in real-time or batches and enable H2M and M2M communication.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>IoT Platform Integration</h4>
                                    <p class="mb-0">Accelerate time-to-ROI and actualize value in your IoT app by integrating it across channels and devices.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>API Development and Integration</h4>
                                    <p class="mb-0">Leverage flexibility and scalability by implementing microservices in API development and integration.</p>


                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Executive Dashboard Development </h4>
                                    <p class="mb-0">Give your business executives the right business intelligence, laid out graphically for faster consumption and decision-making so that they power through their days and focus on metrics that matter.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Testing & Maintenance</h4>
                                    <p class="mb-0">We conduct comprehensive maintenance and testing services to ensure optimal performance of your IoT application and its integrations.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>UX Designing for IoT</h4>
                                    <p class="mb-0">Our IoT application development services include designing a coherent and seamless user experience across devices and software.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>IoT Application Development Services for Wearables </h4>
                                    <p class="mb-0">Leverage IoT applications for wearables and explore a host of possibilities and use cases.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Why M2M for <span class="text-white">IoT Development</span> Services</h2>
                </div>
                <div class="col-12 rnd-cell">
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Security</h4>
                            <p class="mb-0">We keep data governance and secure development best practices top-of-mind with every IoT development project. We also adhere to industry-specific standards and regulations.</p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Scalability</h4>
                            <p class="mb-0">We build for scalability so that when the time comes, your IoT applications and the underlying infrastructure can be appropriately scaled up to support millions of connected devices.</p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Reliable connectivity</h4>
                            <p class="mb-0">IoT applications thrive on connectivity. We ensure a hiccup-free experience with high-quality connectivity by helping you choose the right networking protocol.</p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Top-notch quality</h4>
                            <p class="mb-0">We eliminate risks and ensure quick time-to-market with an outstanding quality of IoT applications through our rigorous quality assurance approach and automated testing.
                            </p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Smooth usability</h4>
                            <p class="mb-0">Our skilled developers and proficient designers put their talent together to create IoT applications that are intuitive, interactive and user-friendly.</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                        <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                        <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                        <li><a href="devops.php">DevOps as a Service</a></li>
                                        <li><a href="product-discovery.php">Product Discovery</a></li>
                                        <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>

</html>

