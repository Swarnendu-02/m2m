<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
<header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                            $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                   <li><a href="marketings.php">Marketing</a></li>
                                    <!-- <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li> -->
                                </ul>
                            </li>
                            <!-- <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li> -->
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">DevOps</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Enhance Business Agility With  <span>DevOps</span></h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>
                            As businesses worldwide embrace digitalization, traditional methods of software development are becoming inadequate and obsolete. As businesses pivot to become more flexible and agile within the digital landscape, DevOps are helping businesses meet their growing digital demands.
<br><br>
DevOps is a modern approach to software engineering that enables organizations to break down silos between teams to integrate development and operations. By achieving true collaboration, we design high-quality software and streamline implementation.
<br><br>
M2M empowers businessesfromstartups to enterprisestocreate a culture of automation and innovation within their organization through our comprehensive DevOps services. Our experienced DevOps consulting team combines people, processes, and technology to drive transformation.
<br><br>
Our DevOps teams coordinate toolchains and automate monitoring, quality assurance evaluations, and remediation. Our continuous release validation of at every stage of the systems development life cycle allow us to reduce application downtime, improve customer satisfaction, and proactively execute end-to-end security integration. 
                            </p>




                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>Orchestrate DevOps toolchains & automate monitoring, quality evaluation, and remediation.</li>
                            <li>Stop wrong code in racks with continuous release validation at every stage of the SDLC.</li>
                            <li>Reduce application downtime, MTTR & improve CSAT by proactively managing SLOs & remediating problems.</li>
                            <li>Execute end-to-end security integration through the ‘Security as Code’ mechanism.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid pb-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center">Our <span>DevOps</span> Service Offerings</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Process Automation</h4>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Release Management</h4>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Security Management</h4>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Continuous Integration & Deployment</h4>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Assessment and Strategy</h4>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>24x7 DevOps Managed Services</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative py-6">
        <div class="process-bk">
            <img src="assets/proccss-bk.png">
        </div>
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">How <span class="text-white">DevOps</span> Uncovers Efficiencies</h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2">
                    <div class=" process-content-cell dev-un">
                        <img src="assets/procss-1.png">
                        <div class="process-box">
                            <div class="mobile-dev-top-lft bg-transparent p-0 text-white">
                                <ul>
                                    <li>Consistent and timely feedback
                                    <li>Early and iterative testing</li>
                                    <li>Continuous integration</li>
                                    <li>Better response to market dynamics</li>
                                    <li>Enhanced collaboration</li>
                                    <li>Automation</li>
                                    <li>Reduce time to market</li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 pb-3">

                    <p class="fontsizepara white px-1">M2M leverages our diverse experience in DevOps consulting and managed service to enable our clients to:</p>

                </div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Enhance throughput</div>
                                </div>
                            </div>
                        </div>
                       <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Reduce costs</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Minimize risks</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2"><img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check"> </div>
                                    <div class="col-10">Facilitate ongoing integration delivery</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Maximize predictable, reliable, and consistent security</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Ensure continuous deployment monitoring</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Optimize business agility</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 white padding-bottom-dev">
                            <div class="word-wrap fontsizepara">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="https://www.kiwitech.com/assets/version7/images/devops/Tick-White.svg" class="icon-blue-check">
                                    </div>
                                    <div class="col-10">Automate redundant tasks</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mt-4">
                            <p class="fontsizepara white px-1">M2M leverages the leading DevOps technologies, cloud infrastructure, end-to-end processes, and 24/7 maintenance and support services to provide your business with value throughout the complete product lifecycle. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row py-6 border-top">
                <div class="owl-carousel owl-theme tec-owl">
                    <div class="item">
                        <img src="assets/python.png">
                        <p>PYTHON DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/React-icon.svg.png">
                        <p>REACT DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/2048px-Angular_full_color_logo.svg.png">
                        <p>ANGULAR DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/PHP-logo.svg.png">
                        <p>PHP DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/ntffgniiqfya5tvzbsol.webp">
                        <p>FRONTEND DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/1200px-Wordpress_Blue_logo.png">
                        <p>WORDPRESS DEVELOPMENT</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern solutions For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    
                                        <!-- <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                        <!-- <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li> -->
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                        <!-- <li><a href="service.php">Services</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <!-- <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li> -->
                                        
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })
    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
                if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".has-drop").removeClass('active-a');
                } else {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                    $(".has-drop").removeClass('active-a');
                    $(this).parent().find(".has-drop").addClass('active-a');
                }
            });
    });
</script>
</html>