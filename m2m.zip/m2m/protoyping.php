<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
    <header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li>
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Prototype</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Fast-Track Your Future With Cutting-Edge <span>Prototyping</span></h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>
                                Refine your product’s design and functionality, eliminate the risk of failure, and validate your product in your target customer segment, by bringing it in action through our software prototype development services.
                                <br><br>
                                We help you test and validate a working prototype quickly, for the customer experience, UI, UX and business use case to raise funding and develop your product with confidence.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>With our services, arrange a series of static images one after another to help visualize your product, its flow and functions.</li>
                            <li>Get help with clickable prototyping to test functionalities, features and underlying tech integrations.</li>
                            <li>With our PoC, define and test the product functionalities, features and integrations for feasibility.</li>
                            <li>With our services refine your product’s design and functionality & eliminate the risk of failure.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center">Our Software <span>Prototyping</span> Service Offerings</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Static Prototyping</h4>
                                    <p class="mb-0">Static prototype development services result in a series of static images put one after another to help visualize your product, its flow and functions. A static prototype visually traces the user journey.</p> 
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Proof of Concept</h4>
                                    <p class="mb-0"> A PoC is a frugal viability test of your core assumption about your product, which reveals whether your product can be realized. A PoC also defines and tests the product functionalities, features and integrations for feasibility.</p> 
                    
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Clickable Prototyping</h4>
                                    <p class="mb-0"> Clickable prototyping results in functional mapping of the user journey, ending in an MVP launch. As good as seeing it in action, clickable prototyping allows you to test functionalities, features and underlying tech integrations.</p> 
                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Our <span class="text-white">Prototyping</span> Process</h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2 app-dev-box web-dev-cell">
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">1</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Understanding Your Idea</h4>
                                <p class="mb-0 text-left">We work with you to understand your innovation.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">2</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Customer Persona</h4>
                                <p class="mb-0 text-left">We help you define the customer so that your product appeals and impacts.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">3</i>
                            <div class="web-del-box">
                                <h4 class="text-left">User Stories</h4>
                                <p class="mb-0 text-left">We give you the opportunity to address specific problems and use cases for your customer, one by one.</p>
                            </div>
                        </div>
                    </div>

                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">7</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Clickable Prototype</h4>
                                <p class="mb-0 text-left">We build on the designed prototype by adding in functionality and navigation.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">8</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Prototype Testing and Iterations</h4>
                                <p class="mb-0 text-left">We test your software prototype comprehensively, reviewing and iterating it.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">9</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Delivery</h4>
                                <p class="mb-0 text-left">Your software prototype is now good to go. Present it to investors and potential customers.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                        <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                        <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                        <li><a href="devops.php">DevOps as a Service</a></li>
                                        <li><a href="product-discovery.php">Product Discovery</a></li>
                                        <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })
    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
            if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                $(".sub-menu").slideUp().removeClass('active');
                $(".has-drop").removeClass('active-a');
            } else {
                $(".sub-menu").slideUp().removeClass('active');
                $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                $(".has-drop").removeClass('active-a');
                $(this).parent().find(".has-drop").addClass('active-a');
            }
        });
    });
</script>

</html>