<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
<header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                   <li><a href="marketings.php">Marketing</a></li>
                                    <!-- <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li> -->
                                </ul>
                            </li>
                            <!-- <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li> -->
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Mobile App Development</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Creating Revolutionary <span>Mobile Experiences</span></h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>We provide Mobile App Development Services to help your business deliver seamless experiences to customers and users. From consumer-oriented apps to enterprise-class solutions, we provide our clients with full-cycle development and implementation. Our team of technical experts deliver a holistic mobile experience—from ideation to delivery and ongoing support.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>Leverage cloud technologies and features such as simple sign-on, in-app purchases, and more</li>
                            <li>Createa cross-platform app across Android, iOS, & Windows platforms while capitalizing on the convenience of design thinking and agile methodologies</li>
                            <li>Utilize our MProgressive App with dynamic upgrades, responsiveness, and ease-of-use</li>
                            <li>Validate your app with a functional prototype, automated testing, and after-service support</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid pb-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2>Our <span>Mobile App Development</span> Service Offerings</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>iOS App Development Services</h4>
                                    <p class="mb-0">We design and deliver our mobile apps to align with business, operational, and security requirements. Our native iOS app development services team works with you to launch a successful app across the iPhone, iPad, Apple Watch, and Apple TV platforms.</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Android App Development Services</h4>
                                    <p class="mb-0">Our expert technical teams deliver Android apps designed to engage and inform your customers while offering value throughout their user experience. We provide native Android app development services across the mobile app development lifecycle, including leveraging cloud technologies, innovative AI tools, and unique eCommerce features such as in-app purchases. </p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Cross-platform App Development Services</h4>
                                    <p class="mb-0">Create consistent experiences for your customers, market, and industry with our cross-platform mobile app development services. Our expert developers design your apps in a way that ensures your business and brand have a consistent presence across multiple platforms including Android, iOS and Windows.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Progressive App Development Services</h4>
                                    <p class="mb-0">Create an immersive user experience with progressive apps that look and function like traditional mobile apps. Our progressive apps are designed with dynamic upgrades, responsiveness, and ease-of-use to provide your target audience with an innovative and customized online experience. 
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>UI/UX Mobile App Designing Services</h4>
                                    <p class="mb-0">Exceptional mobile app design is all about creating a simplified user-centric experience—no matter which products or services your business offers. Our expert UI/UX specialists deliver aesthetic and functional designs that elevate your app into a memorable and useful resource for customers.</p>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Mobile App Prototyping Services</h4>
                                    <p class="mb-0">Prototyping is a key part of our mobile app development services. Before the launch of your mobile app, we perform testing and validation and engage stakeholders for feedback that can be used to optimize functionality. Our rigorous testing ensures that your ideas are validated with a functional prototype before you invest further in its development.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Enterprise Mobility Solutions</h4>
                                    <p class="mb-0">Provide exceptional customer service and simplify internal business processes with our enterprise mobile app development services. Promote engagement and integrate features specific to your needs with our custom-designed and easy-to-use mobility solutions.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Automated QA and Testing</h4>
                                    <p class="mb-0">Deliver a seamless mobile app experience to users with our automated testing and quality assurance audits. Our comprehensive application testing detects loopholes, leakages, system vulnerabilities, and user experience concerns—both prior to launch and ongoing once it’s live. Our testing and QA methodologies enable our design team to monitor performance metrics for future optimization. </p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>App Maintenance and Support </h4>
                                    <p class="mb-0">We provide reliable 24/7 support and maintenance for your mobile app. Our experienced team has open availability to ensure any problem—from minor glitches to serious technical issues—are addressed quickly and effectively. Our dedicated team also ensure minimal downtime during application upgrades and maintenance activities.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">How A <span class="text-white">Mobile App</span> Benefits Your Business</h2>
                </div>
                <div class="col-12 rnd-cell">
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Customer Engagement</h4>
                            <p class="mb-0">Engage users and app visitors and convert them into customers through mobile applications. Increase the reach and influence of your brand, products, and services by providing an informative and authoritative mobile resource for new and existing customers—accessible on any modern smartphone or mobile device. </p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Improved Sales Performance</h4>
                            <p class="mb-0">Enhance sales and boost customer engagement with mobile app marketing. Push notifications and in-app alerts are sent directly to your customers’ smartphones—creating endless opportunities for digital marketing strategies that convert casual visitors into repeat customers.</p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Competitive Edge</h4>
                            <p class="mb-0">Gain an advantage over your competitors with a seamless mobile app experience that solidifies your brand while promoting the benefits of your products and services. With the increased adoption of smartphones amongst most consumers, businesses who pivot and embrace digitalization realize increased sales and enhanced customer experiences.</p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>Immediate Point-of-Contact</h4>
                            <p class="mb-0">Creating a diverse online presence for your business allows you to connect directly to your target audience worldwide. Designing a unique, branded mobile app for your business is a cost-effective way to market and communicate instantly with millions of potential buyers in your market segment.
                            </p>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent">
                            <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto;">
                            <h4>A Consistent Touchpoint</h4>
                            <p class="mb-0">As consumer trends and behaviours evolve and more businesses adopt “digital-first” business models, mobile communication is more popular than ever. An informative mobile app gives your customers with a deeper connection to your business while providing a consistent and reliable customer experience.</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row py-6 border-top">
                <div class="owl-carousel owl-theme tec-owl">
                    <div class="item">
                        <img src="assets/python.png">
                        <p>PYTHON DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/React-icon.svg.png">
                        <p>REACT DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/2048px-Angular_full_color_logo.svg.png">
                        <p>ANGULAR DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/PHP-logo.svg.png">
                        <p>PHP DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/ntffgniiqfya5tvzbsol.webp">
                        <p>FRONTEND DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/1200px-Wordpress_Blue_logo.png">
                        <p>WORDPRESS DEVELOPMENT</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern solutions For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    
                                        <!-- <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                        <!-- <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li> -->
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                        <!-- <li><a href="service.php">Services</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <!-- <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li> -->
                                        
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
                if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".has-drop").removeClass('active-a');
                } else {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                    $(".has-drop").removeClass('active-a');
                    $(this).parent().find(".has-drop").addClass('active-a');
                }
            });
    });
</script>
</html>